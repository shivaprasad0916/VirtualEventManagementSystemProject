using DAL.Context;
using DAL.Models;
using Microsoft.EntityFrameworkCore;

namespace DAL.Repository
{
    public class SpeakerRepository : ISpeakerRepository
    {
        private readonly EMSDbContext _context;

        public SpeakerRepository(EMSDbContext context) => _context = context;

        public async Task<IEnumerable<SpeakersDetails>> GetAllAsync()
            => await _context.Speakers.ToListAsync();

        public async Task<SpeakersDetails?> GetByIdAsync(object id)
            => await _context.Speakers.FindAsync((Guid)id);

        public async Task AddAsync(SpeakersDetails entity)
        {
            entity.SpeakerId = Guid.NewGuid();
            await _context.Speakers.AddAsync(entity);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(SpeakersDetails entity)
        {
            _context.Speakers.Update(entity);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(object id)
        {
            var speaker = await _context.Speakers.FindAsync((Guid)id);
            if (speaker != null)
            {
                _context.Speakers.Remove(speaker);
                await _context.SaveChangesAsync();
            }
        }

        public async Task<bool> ExistsAsync(object id)
            => await _context.Speakers.AnyAsync(s => s.SpeakerId == (Guid)id);

        public async Task<IEnumerable<SpeakersDetails>> GetSpeakersWithSessionsAsync()
            => await _context.Speakers.Include(s => s.Sessions).ToListAsync();
    }
}
