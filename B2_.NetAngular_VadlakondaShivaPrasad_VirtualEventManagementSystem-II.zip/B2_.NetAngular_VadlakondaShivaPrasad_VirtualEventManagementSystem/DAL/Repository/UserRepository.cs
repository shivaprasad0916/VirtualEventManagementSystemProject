using DAL.Context;
using DAL.Models;
using Microsoft.EntityFrameworkCore;

namespace DAL.Repository
{
    public class UserRepository : IUserRepository
    {
        private readonly EMSDbContext _context;

        public UserRepository(EMSDbContext context) => _context = context;

        public async Task<IEnumerable<UserInfo>> GetAllAsync()
            => await _context.Users.ToListAsync();

        public async Task<UserInfo?> GetByIdAsync(object id)
            => await _context.Users.FindAsync((string)id);

        public async Task AddAsync(UserInfo entity)
        {
            await _context.Users.AddAsync(entity);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(UserInfo entity)
        {
            _context.Users.Update(entity);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(object id)
        {
            var user = await _context.Users.FindAsync((string)id);
            if (user != null)
            {
                _context.Users.Remove(user);
                await _context.SaveChangesAsync();
            }
        }

        public async Task<bool> ExistsAsync(object id)
            => await _context.Users.AnyAsync(u => u.EmailId == (string)id);

        public async Task<UserInfo?> AuthenticateAsync(string email, string password)
            => await _context.Users
                             .FirstOrDefaultAsync(u => u.EmailId == email && u.Password == password);

        public async Task<bool> EmailExistsAsync(string email)
            => await _context.Users.AnyAsync(u => u.EmailId == email);
    }
}
