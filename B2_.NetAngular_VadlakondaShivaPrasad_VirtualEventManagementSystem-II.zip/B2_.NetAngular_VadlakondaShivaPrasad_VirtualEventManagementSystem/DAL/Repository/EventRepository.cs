using DAL.Context;
using DAL.Models;
using Microsoft.EntityFrameworkCore;

namespace DAL.Repository
{
    public class EventRepository : IEventRepository
    {
        private readonly EMSDbContext _context;

        public EventRepository(EMSDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<EventDetails>> GetAllAsync()
            => await _context.Events.Include(e => e.Sessions).ToListAsync();

        public async Task<EventDetails?> GetByIdAsync(object id)
            => await _context.Events
                             .Include(e => e.Sessions)
                             .ThenInclude(s => s.Speaker)
                             .FirstOrDefaultAsync(e => e.EventId == (Guid)id);

        public async Task AddAsync(EventDetails entity)
        {
            entity.EventId = Guid.NewGuid();
            await _context.Events.AddAsync(entity);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(EventDetails entity)
        {
            _context.Events.Update(entity);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(object id)
        {
            var ev = await _context.Events.FindAsync((Guid)id);
            if (ev != null)
            {
                _context.Events.Remove(ev);
                await _context.SaveChangesAsync();
            }
        }

        public async Task<bool> ExistsAsync(object id)
            => await _context.Events.AnyAsync(e => e.EventId == (Guid)id);

        public async Task<IEnumerable<EventDetails>> GetByStatusAsync(string status)
            => await _context.Events.Where(e => e.Status == status).ToListAsync();

        public async Task<IEnumerable<EventDetails>> GetByCategoryAsync(string category)
            => await _context.Events.Where(e => e.EventCategory == category).ToListAsync();

        public async Task<IEnumerable<string>> GetCategoriesAsync()
            => await _context.Events.Select(e => e.EventCategory).Distinct().ToListAsync();

        public async Task ToggleStatusAsync(Guid eventId)
        {
            var ev = await _context.Events.FindAsync(eventId);
            if (ev != null)
            {
                ev.Status = ev.Status == "Active" ? "In-Active" : "Active";
                await _context.SaveChangesAsync();
            }
        }
    }
}
