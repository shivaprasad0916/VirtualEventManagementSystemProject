using DAL.Models;

namespace DAL.Repository
{
    public interface ISessionRepository : IRepository<SessionInfo>
    {
        Task<IEnumerable<SessionInfo>> GetByEventAsync(Guid eventId);
        Task AssignSpeakerAsync(Guid sessionId, Guid speakerId);
    }
}
