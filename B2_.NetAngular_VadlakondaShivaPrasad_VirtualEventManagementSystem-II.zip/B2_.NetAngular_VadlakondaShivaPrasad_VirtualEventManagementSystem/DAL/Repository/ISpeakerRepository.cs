using DAL.Models;

namespace DAL.Repository
{
    public interface ISpeakerRepository : IRepository<SpeakersDetails>
    {
        Task<IEnumerable<SpeakersDetails>> GetSpeakersWithSessionsAsync();
    }
}
