using DAL.Context;
using DAL.Models;
using Microsoft.EntityFrameworkCore;

namespace DAL.Repository
{
    public class ParticipantRepository : IParticipantRepository
    {
        private readonly EMSDbContext _context;

        public ParticipantRepository(EMSDbContext context) => _context = context;

        public async Task<IEnumerable<ParticipantEventDetails>> GetAllAsync()
            => await _context.ParticipantEvents
                             .Include(p => p.Participant)
                             .Include(p => p.Event)
                             .ToListAsync();

        public async Task<ParticipantEventDetails?> GetByIdAsync(object id)
            => await _context.ParticipantEvents
                             .Include(p => p.Event)
                             .ThenInclude(e => e!.Sessions)
                             .FirstOrDefaultAsync(p => p.ID == (Guid)id);

        public async Task AddAsync(ParticipantEventDetails entity)
        {
            entity.ID = Guid.NewGuid();
            await _context.ParticipantEvents.AddAsync(entity);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(ParticipantEventDetails entity)
        {
            _context.ParticipantEvents.Update(entity);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(object id)
        {
            var p = await _context.ParticipantEvents.FindAsync((Guid)id);
            if (p != null)
            {
                _context.ParticipantEvents.Remove(p);
                await _context.SaveChangesAsync();
            }
        }

        public async Task<bool> ExistsAsync(object id)
            => await _context.ParticipantEvents.AnyAsync(p => p.ID == (Guid)id);

        public async Task<IEnumerable<ParticipantEventDetails>> GetByParticipantAsync(string email)
            => await _context.ParticipantEvents
                             .Include(p => p.Event)
                             .ThenInclude(e => e!.Sessions)
                             .ThenInclude(s => s.Speaker)
                             .Where(p => p.ParticipantEmailId == email)
                             .ToListAsync();

        public async Task<bool> IsRegisteredAsync(string email, Guid eventId)
            => await _context.ParticipantEvents
                             .AnyAsync(p => p.ParticipantEmailId == email && p.EventId == eventId);

        public async Task MarkAttendanceAsync(Guid participantEventId, bool attended)
        {
            var p = await _context.ParticipantEvents.FindAsync(participantEventId);
            if (p != null)
            {
                p.IsAttended = attended;
                await _context.SaveChangesAsync();
            }
        }
    }
}
