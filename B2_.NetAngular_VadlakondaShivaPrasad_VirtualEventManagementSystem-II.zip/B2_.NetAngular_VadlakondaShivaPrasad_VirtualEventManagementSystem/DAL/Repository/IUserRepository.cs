using DAL.Models;

namespace DAL.Repository
{
    public interface IUserRepository : IRepository<UserInfo>
    {
        Task<UserInfo?> AuthenticateAsync(string email, string password);
        Task<bool> EmailExistsAsync(string email);
    }
}
