using DAL.Models;

namespace DAL.Repository
{
    public interface IParticipantRepository : IRepository<ParticipantEventDetails>
    {
        Task<IEnumerable<ParticipantEventDetails>> GetByParticipantAsync(string email);
        Task<bool> IsRegisteredAsync(string email, Guid eventId);
        Task MarkAttendanceAsync(Guid participantEventId, bool attended);
    }
}
