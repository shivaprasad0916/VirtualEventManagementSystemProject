using DAL.Context;
using DAL.Models;
using Microsoft.EntityFrameworkCore;

namespace DAL.Repository
{
    public class SessionRepository : ISessionRepository
    {
        private readonly EMSDbContext _context;

        public SessionRepository(EMSDbContext context) => _context = context;

        public async Task<IEnumerable<SessionInfo>> GetAllAsync()
            => await _context.Sessions
                             .Include(s => s.Event)
                             .Include(s => s.Speaker)
                             .ToListAsync();

        public async Task<SessionInfo?> GetByIdAsync(object id)
            => await _context.Sessions
                             .Include(s => s.Event)
                             .Include(s => s.Speaker)
                             .FirstOrDefaultAsync(s => s.SessionId == (Guid)id);

        public async Task AddAsync(SessionInfo entity)
        {
            entity.SessionId = Guid.NewGuid();
            await _context.Sessions.AddAsync(entity);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(SessionInfo entity)
        {
            _context.Sessions.Update(entity);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(object id)
        {
            var session = await _context.Sessions.FindAsync((Guid)id);
            if (session != null)
            {
                _context.Sessions.Remove(session);
                await _context.SaveChangesAsync();
            }
        }

        public async Task<bool> ExistsAsync(object id)
            => await _context.Sessions.AnyAsync(s => s.SessionId == (Guid)id);

        public async Task<IEnumerable<SessionInfo>> GetByEventAsync(Guid eventId)
            => await _context.Sessions
                             .Include(s => s.Speaker)
                             .Where(s => s.EventId == eventId)
                             .ToListAsync();

        public async Task AssignSpeakerAsync(Guid sessionId, Guid speakerId)
        {
            var session = await _context.Sessions.FindAsync(sessionId);
            if (session != null)
            {
                session.SpeakerId = speakerId;
                await _context.SaveChangesAsync();
            }
        }
    }
}
