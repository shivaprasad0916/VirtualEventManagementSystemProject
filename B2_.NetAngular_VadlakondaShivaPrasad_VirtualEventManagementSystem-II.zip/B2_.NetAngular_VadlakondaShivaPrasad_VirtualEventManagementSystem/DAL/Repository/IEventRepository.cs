using DAL.Models;

namespace DAL.Repository
{
    public interface IEventRepository : IRepository<EventDetails>
    {
        Task<IEnumerable<EventDetails>> GetByStatusAsync(string status);
        Task<IEnumerable<EventDetails>> GetByCategoryAsync(string category);
        Task<IEnumerable<string>> GetCategoriesAsync();
        Task ToggleStatusAsync(Guid eventId);
    }
}
