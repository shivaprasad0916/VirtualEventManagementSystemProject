using DAL.Models;
using Microsoft.EntityFrameworkCore;

namespace DAL.Context
{
    public class EMSDbContext : DbContext
    {
        public EMSDbContext(DbContextOptions<EMSDbContext> options) : base(options) { }

        public DbSet<UserInfo> Users { get; set; }
        public DbSet<EventDetails> Events { get; set; }
        public DbSet<SpeakersDetails> Speakers { get; set; }
        public DbSet<SessionInfo> Sessions { get; set; }
        public DbSet<ParticipantEventDetails> ParticipantEvents { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // UserInfo
            modelBuilder.Entity<UserInfo>(entity =>
            {
                entity.HasKey(u => u.EmailId);
                entity.Property(u => u.UserName).IsRequired().HasMaxLength(50);
                entity.Property(u => u.Role).IsRequired();
                entity.Property(u => u.Password).IsRequired().HasMaxLength(20);
            });

            // EventDetails
            modelBuilder.Entity<EventDetails>(entity =>
            {
                entity.HasKey(e => e.EventId);
                entity.Property(e => e.EventId).ValueGeneratedOnAdd();
                entity.Property(e => e.EventName).IsRequired().HasMaxLength(50);
                entity.Property(e => e.EventCategory).IsRequired().HasMaxLength(50);
                entity.Property(e => e.EventDate).IsRequired();
                entity.Property(e => e.Description).IsRequired(false);
                entity.Property(e => e.Status).IsRequired().HasDefaultValue("Active");
            });

            // SpeakersDetails
            modelBuilder.Entity<SpeakersDetails>(entity =>
            {
                entity.HasKey(s => s.SpeakerId);
                entity.Property(s => s.SpeakerId).ValueGeneratedOnAdd();
                entity.Property(s => s.SpeakerName).IsRequired().HasMaxLength(50);
            });

            // SessionInfo
            modelBuilder.Entity<SessionInfo>(entity =>
            {
                entity.HasKey(s => s.SessionId);
                entity.Property(s => s.SessionId).ValueGeneratedOnAdd();
                entity.Property(s => s.SessionTitle).IsRequired().HasMaxLength(50);
                entity.Property(s => s.Description).IsRequired(false);
                entity.Property(s => s.SessionUrl).IsRequired(false);

                // FK: SessionInfo → EventDetails (required, cascade delete)
                entity.HasOne(s => s.Event)
                      .WithMany(e => e.Sessions)
                      .HasForeignKey(s => s.EventId)
                      .OnDelete(DeleteBehavior.Cascade);

                // FK: SessionInfo → SpeakersDetails (optional, set null on delete)
                entity.HasOne(s => s.Speaker)
                      .WithMany(sp => sp.Sessions)
                      .HasForeignKey(s => s.SpeakerId)
                      .IsRequired(false)
                      .OnDelete(DeleteBehavior.SetNull);
            });

            // ParticipantEventDetails
            modelBuilder.Entity<ParticipantEventDetails>(entity =>
            {
                entity.HasKey(p => p.ID);
                entity.Property(p => p.ID).ValueGeneratedOnAdd();
                entity.Property(p => p.IsAttended).HasDefaultValue(false);

                // Unique constraint: one registration per participant per event
                entity.HasIndex(p => new { p.ParticipantEmailId, p.EventId }).IsUnique();

                // FK: ParticipantEventDetails → UserInfo
                entity.HasOne(p => p.Participant)
                      .WithMany(u => u.ParticipantEvents)
                      .HasForeignKey(p => p.ParticipantEmailId)
                      .OnDelete(DeleteBehavior.Cascade);

                // FK: ParticipantEventDetails → EventDetails
                entity.HasOne(p => p.Event)
                      .WithMany(e => e.ParticipantEvents)
                      .HasForeignKey(p => p.EventId)
                      .OnDelete(DeleteBehavior.Restrict);
            });

            // Seed Admin User
            modelBuilder.Entity<UserInfo>().HasData(new UserInfo
            {
                EmailId = "admin@upgrad.com",
                UserName = "Admin",
                Role = "Admin",
                Password = "admin123"
            });
        }
    }
}
