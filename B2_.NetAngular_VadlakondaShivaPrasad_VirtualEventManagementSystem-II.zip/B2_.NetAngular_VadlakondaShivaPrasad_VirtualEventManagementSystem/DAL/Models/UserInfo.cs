using System.ComponentModel.DataAnnotations;

namespace DAL.Models
{
    public class UserInfo
    {
        [Key]
        [Required]
        [EmailAddress]
        public string EmailId { get; set; } = string.Empty;

        [Required]
        [StringLength(50, MinimumLength = 1, ErrorMessage = "UserName must be between 1 and 50 characters.")]
        public string UserName { get; set; } = string.Empty;

        [Required]
        [RegularExpression("Admin|Participant", ErrorMessage = "Role must be either 'Admin' or 'Participant'.")]
        public string Role { get; set; } = "Participant";

        [Required]
        [StringLength(20, MinimumLength = 6, ErrorMessage = "Password must be between 6 and 20 characters.")]
        public string Password { get; set; } = string.Empty;

        // Navigation property
        public ICollection<ParticipantEventDetails> ParticipantEvents { get; set; } = new List<ParticipantEventDetails>();
    }
}
