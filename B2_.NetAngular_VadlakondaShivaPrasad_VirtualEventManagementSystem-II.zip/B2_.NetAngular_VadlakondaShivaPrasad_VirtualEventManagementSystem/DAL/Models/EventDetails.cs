using System.ComponentModel.DataAnnotations;

namespace DAL.Models
{
    public class EventDetails
    {
        [Key]
        public Guid EventId { get; set; } = Guid.NewGuid();

        [Required]
        [StringLength(50, MinimumLength = 1, ErrorMessage = "EventName must be between 1 and 50 characters.")]
        public string EventName { get; set; } = string.Empty;

        [Required]
        [StringLength(50, MinimumLength = 1, ErrorMessage = "EventCategory must be between 1 and 50 characters.")]
        public string EventCategory { get; set; } = string.Empty;

        [Required]
        public DateTime EventDate { get; set; }

        public string? Description { get; set; }

        [Required]
        [RegularExpression("Active|In-Active", ErrorMessage = "Status must be 'Active' or 'In-Active'.")]
        public string Status { get; set; } = "Active";

        // Navigation properties
        public ICollection<SessionInfo> Sessions { get; set; } = new List<SessionInfo>();
        public ICollection<ParticipantEventDetails> ParticipantEvents { get; set; } = new List<ParticipantEventDetails>();
    }
}
