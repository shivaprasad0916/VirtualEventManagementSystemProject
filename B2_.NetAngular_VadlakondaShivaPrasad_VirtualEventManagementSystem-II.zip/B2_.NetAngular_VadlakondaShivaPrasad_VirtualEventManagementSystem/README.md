# upGrad Virtual Event Management System — Phase 2

A full-stack **ASP.NET Core MVC** application backed by **Entity Framework Core (Code First)** and **SQL Server**.

---

## Project Structure

```
EMS/
├── EMS.sln
├── DAL/                            ← Class Library (Data Access Layer)
│   ├── DAL.csproj
│   ├── Models/
│   │   ├── UserInfo.cs
│   │   ├── EventDetails.cs
│   │   ├── SpeakersDetails.cs
│   │   ├── SessionInfo.cs
│   │   └── ParticipantEventDetails.cs
│   ├── Context/
│   │   └── EMSDbContext.cs         ← DbContext + Fluent API config + seed
│   ├── Repository/
│   │   ├── IRepository.cs          ← Generic interface
│   │   ├── IEventRepository.cs     ← + EventRepository.cs
│   │   ├── ISessionRepository.cs   ← + SessionRepository.cs
│   │   ├── ISpeakerRepository.cs   ← + SpeakerRepository.cs
│   │   ├── IUserRepository.cs      ← + UserRepository.cs
│   │   └── IParticipantRepository.cs ← + ParticipantRepository.cs
│   └── Migrations/
│       ├── 20240101000000_InitialCreate.cs
│       └── EMSDbContextModelSnapshot.cs
│
└── AppUI/                          ← ASP.NET Core MVC Application
    ├── AppUI.csproj
    ├── Program.cs                  ← DI, middleware, session config
    ├── appsettings.json            ← Connection string
    ├── Controllers/
    │   ├── HomeController.cs       ← Public event browsing
    │   ├── AccountController.cs    ← Login / Register / Logout
    │   ├── AdminController.cs      ← Full CRUD (Events, Sessions, Speakers)
    │   └── ParticipantController.cs← Dashboard, register, attendance
    ├── Models/
    │   ├── AccountViewModels.cs    ← LoginViewModel, RegisterViewModel
    │   └── EventViewModels.cs      ← EventVM, SessionVM, SpeakerVM, etc.
    └── Views/
        ├── _ViewImports.cshtml
        ├── _ViewStart.cshtml
        ├── Shared/
        │   ├── _AdminLayout.cshtml       ← Sidebar layout for admin
        │   ├── _ParticipantLayout.cshtml ← Top-nav layout for participants
        │   └── _ValidationScriptsPartial.cshtml
        ├── Home/
        │   ├── Index.cshtml        ← Event listing + category filter
        │   └── EventDetails.cshtml ← Event detail + sessions + register CTA
        ├── Account/
        │   ├── Login.cshtml
        │   └── Register.cshtml
        ├── Admin/
        │   ├── Dashboard.cshtml
        │   ├── Events.cshtml
        │   ├── CreateEvent.cshtml
        │   ├── EditEvent.cshtml
        │   ├── Sessions.cshtml
        │   ├── CreateSession.cshtml
        │   ├── AssignSpeaker.cshtml
        │   ├── Speakers.cshtml
        │   └── CreateSpeaker.cshtml
        └── Participant/
            ├── Dashboard.cshtml
            └── RegisteredEvents.cshtml
```

---

## Prerequisites

| Tool | Version |
|------|---------|
| .NET SDK | 8.0+ |
| SQL Server | 2019+ or LocalDB |
| Visual Studio | 2022 (or VS Code + C# Dev Kit) |
| EF Core Tools | `dotnet tool install --global dotnet-ef` |

---

## Setup & Run

### 1. Clone / extract the project

```bash
cd EMS
```

### 2. Update connection string

Edit `AppUI/appsettings.json`:

```json
"ConnectionStrings": {
  "EMSConnection": "Server=(localdb)\\mssqllocaldb;Database=UpGradEMS;Trusted_Connection=True;"
}
```

For SQL Server Express: `Server=.\\SQLEXPRESS;Database=UpGradEMS;Trusted_Connection=True;`

### 3. Apply database migrations

```bash
cd AppUI
dotnet ef database update --project ../DAL/DAL.csproj
```

> The migration auto-applies on startup too (`db.Database.Migrate()` in `Program.cs`).

### 4. Run the application

```bash
dotnet run --project AppUI/AppUI.csproj
```

Open: **https://localhost:5001**

---

## Default Credentials

| Role | Email | Password |
|------|-------|----------|
| Admin | admin@upgrad.com | Admin@123 |
| Participant | _(register yourself)_ | — |

---

## Navigation Flow

### Admin
```
/Account/Login  →  /Admin/Dashboard
                       ├── /Admin/Events       (list, add, edit, delete, toggle status)
                       ├── /Admin/Sessions      (list, add, delete, assign speaker)
                       └── /Admin/Speakers      (list, add, delete)
```

### Participant
```
/  (Home — event listing)
   └── /Home/EventDetails/{id}
           └── Login to Register  →  /Account/Login
                                          └── /Participant/Dashboard
                                                  └── /Participant/RegisteredEvents
                                                          (mark attendance, cancel)
```

---

## Key Design Decisions

| Concern | Approach |
|---------|----------|
| Architecture | 3-layer: UI → Repository → EF Core → SQL Server |
| ORM | Code-First with Fluent API in `OnModelCreating` |
| Auth | Session-based (`HttpContext.Session`) |
| Layouts | Two separate: `_AdminLayout` (sidebar) + `_ParticipantLayout` (top-nav) |
| Validation | DataAnnotations on both DAL models and UI ViewModels |
| Date rules | EventDate > today, SessionEnd > SessionStart (validated in controller) |
| Duplicate guard | Unique index on `(ParticipantEmailId, EventId)` prevents double registration |
| Cascade rules | Session deleted when Event deleted; Speaker removal sets SpeakerId to NULL |

---

## Running Migrations Manually (if needed)

```bash
# From solution root
dotnet ef migrations add <MigrationName> \
  --project DAL/DAL.csproj \
  --startup-project AppUI/AppUI.csproj

dotnet ef database update \
  --project DAL/DAL.csproj \
  --startup-project AppUI/AppUI.csproj
```
