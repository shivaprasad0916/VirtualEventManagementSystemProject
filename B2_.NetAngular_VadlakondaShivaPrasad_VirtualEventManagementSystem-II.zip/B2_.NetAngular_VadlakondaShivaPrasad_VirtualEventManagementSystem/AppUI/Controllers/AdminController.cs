using AppUI.Models;
using DAL.Models;
using DAL.Repository;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace AppUI.Controllers
{
    public class AdminController : Controller
    {
        private readonly IEventRepository   _eventRepo;
        private readonly ISessionRepository _sessionRepo;
        private readonly ISpeakerRepository _speakerRepo;

        public AdminController(
            IEventRepository   eventRepo,
            ISessionRepository sessionRepo,
            ISpeakerRepository speakerRepo)
        {
            _eventRepo   = eventRepo;
            _sessionRepo = sessionRepo;
            _speakerRepo = speakerRepo;
        }

        // Guard: only Admin may access
        private bool IsAdmin()
            => HttpContext.Session.GetString("UserRole") == "Admin";

        private IActionResult AdminGuard()
            => IsAdmin() ? null! : RedirectToAction("Login", "Account");

        // Dashboard
        public async Task<IActionResult> Dashboard()
        {
            var guard = AdminGuard(); if (guard != null) return guard;

            ViewBag.TotalEvents   = (await _eventRepo.GetAllAsync()).Count();
            ViewBag.TotalSessions = (await _sessionRepo.GetAllAsync()).Count();
            ViewBag.TotalSpeakers = (await _speakerRepo.GetAllAsync()).Count();
            return View();
        }

        // Events
        public async Task<IActionResult> Events()
        {
            var guard = AdminGuard(); if (guard != null) return guard;

            var events = await _eventRepo.GetAllAsync();
            var vms = events.Select(e => new EventViewModel
            {
                EventId       = e.EventId,
                EventName     = e.EventName,
                EventCategory = e.EventCategory,
                EventDate     = e.EventDate,
                Description   = e.Description,
                Status        = e.Status
            }).ToList();
            return View(vms);
        }

        [HttpGet]
        public IActionResult CreateEvent()
        {
            var guard = AdminGuard(); if (guard != null) return guard;
            return View(new EventViewModel { EventDate = DateTime.Today.AddDays(1) });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateEvent(EventViewModel model)
        {
            var guard = AdminGuard(); if (guard != null) return guard;

            if (model.EventDate <= DateTime.Today)
                ModelState.AddModelError("EventDate", "Event date must be in the future.");

            if (!ModelState.IsValid) return View(model);

            await _eventRepo.AddAsync(new EventDetails
            {
                EventName     = model.EventName,
                EventCategory = model.EventCategory,
                EventDate     = model.EventDate,
                Description   = model.Description,
                Status        = model.Status
            });

            TempData["Success"] = "Event created successfully.";
            return RedirectToAction(nameof(Events));
        }

        [HttpGet]
        public async Task<IActionResult> EditEvent(Guid id)
        {
            var guard = AdminGuard(); if (guard != null) return guard;

            var ev = await _eventRepo.GetByIdAsync(id);
            if (ev == null) return NotFound();

            return View(new EventViewModel
            {
                EventId       = ev.EventId,
                EventName     = ev.EventName,
                EventCategory = ev.EventCategory,
                EventDate     = ev.EventDate,
                Description   = ev.Description,
                Status        = ev.Status
            });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditEvent(EventViewModel model)
        {
            var guard = AdminGuard(); if (guard != null) return guard;

            if (model.EventDate <= DateTime.Today)
                ModelState.AddModelError("EventDate", "Event date must be in the future.");

            if (!ModelState.IsValid) return View(model);

            await _eventRepo.UpdateAsync(new EventDetails
            {
                EventId       = model.EventId,
                EventName     = model.EventName,
                EventCategory = model.EventCategory,
                EventDate     = model.EventDate,
                Description   = model.Description,
                Status        = model.Status
            });

            TempData["Success"] = "Event updated successfully.";
            return RedirectToAction(nameof(Events));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteEvent(Guid id)
        {
            var guard = AdminGuard(); if (guard != null) return guard;
            await _eventRepo.DeleteAsync(id);
            TempData["Success"] = "Event deleted.";
            return RedirectToAction(nameof(Events));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ToggleEventStatus(Guid id)
        {
            var guard = AdminGuard(); if (guard != null) return guard;
            await _eventRepo.ToggleStatusAsync(id);
            return RedirectToAction(nameof(Events));
        }

        // Sessions
        public async Task<IActionResult> Sessions(Guid? eventId)
        {
            var guard = AdminGuard(); if (guard != null) return guard;

            IEnumerable<DAL.Models.SessionInfo> sessions;
            if (eventId.HasValue)
                sessions = await _sessionRepo.GetByEventAsync(eventId.Value);
            else
                sessions = await _sessionRepo.GetAllAsync();

            var vms = sessions.Select(s => new SessionViewModel
            {
                SessionId    = s.SessionId,
                EventId      = s.EventId,
                EventName    = s.Event?.EventName,
                SessionTitle = s.SessionTitle,
                SpeakerId    = s.SpeakerId,
                SpeakerName  = s.Speaker?.SpeakerName,
                Description  = s.Description,
                SessionStart = s.SessionStart,
                SessionEnd   = s.SessionEnd,
                SessionUrl   = s.SessionUrl
            }).ToList();

            ViewBag.FilterEventId = eventId;
            return View(vms);
        }

        [HttpGet]
        public async Task<IActionResult> CreateSession(Guid? eventId)
        {
            var guard = AdminGuard(); if (guard != null) return guard;

            var events   = await _eventRepo.GetAllAsync();
            var speakers = await _speakerRepo.GetAllAsync();

            ViewBag.Events   = new SelectList(events,   "EventId",   "EventName",   eventId);
            ViewBag.Speakers = new SelectList(speakers, "SpeakerId", "SpeakerName");

            return View(new SessionViewModel
            {
                EventId      = eventId ?? Guid.Empty,
                SessionStart = DateTime.Now,
                SessionEnd   = DateTime.Now.AddHours(1)
            });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateSession(SessionViewModel model)
        {
            var guard = AdminGuard(); if (guard != null) return guard;

            if (model.SessionEnd <= model.SessionStart)
                ModelState.AddModelError("SessionEnd", "Session end must be after session start.");

            if (!await _eventRepo.ExistsAsync(model.EventId))
                ModelState.AddModelError("EventId", "Selected event does not exist.");

            if (!ModelState.IsValid)
            {
                var events   = await _eventRepo.GetAllAsync();
                var speakers = await _speakerRepo.GetAllAsync();
                ViewBag.Events   = new SelectList(events,   "EventId",   "EventName");
                ViewBag.Speakers = new SelectList(speakers, "SpeakerId", "SpeakerName");
                return View(model);
            }

            await _sessionRepo.AddAsync(new DAL.Models.SessionInfo
            {
                EventId      = model.EventId,
                SessionTitle = model.SessionTitle,
                SpeakerId    = model.SpeakerId,
                Description  = model.Description,
                SessionStart = model.SessionStart,
                SessionEnd   = model.SessionEnd,
                SessionUrl   = model.SessionUrl
            });

            TempData["Success"] = "Session added successfully.";
            return RedirectToAction(nameof(Sessions));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteSession(Guid id)
        {
            var guard = AdminGuard(); if (guard != null) return guard;
            await _sessionRepo.DeleteAsync(id);
            TempData["Success"] = "Session deleted.";
            return RedirectToAction(nameof(Sessions));
        }

        // Assign Speaker
        [HttpGet]
        public async Task<IActionResult> AssignSpeaker(Guid sessionId)
        {
            var guard = AdminGuard(); if (guard != null) return guard;

            var session  = await _sessionRepo.GetByIdAsync(sessionId);
            if (session == null) return NotFound();

            var speakers = await _speakerRepo.GetAllAsync();
            var vm = new AssignSpeakerViewModel
            {
                SessionId         = sessionId,
                SessionTitle      = session.SessionTitle,
                SpeakerId         = session.SpeakerId ?? Guid.Empty,
                AvailableSpeakers = speakers.Select(s => new SpeakerViewModel
                {
                    SpeakerId   = s.SpeakerId,
                    SpeakerName = s.SpeakerName
                }).ToList()
            };
            return View(vm);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AssignSpeaker(AssignSpeakerViewModel model)
        {
            var guard = AdminGuard(); if (guard != null) return guard;

            if (!await _speakerRepo.ExistsAsync(model.SpeakerId))
            {
                ModelState.AddModelError("SpeakerId", "Selected speaker does not exist.");
                model.AvailableSpeakers = (await _speakerRepo.GetAllAsync())
                    .Select(s => new SpeakerViewModel { SpeakerId = s.SpeakerId, SpeakerName = s.SpeakerName }).ToList();
                return View(model);
            }

            await _sessionRepo.AssignSpeakerAsync(model.SessionId, model.SpeakerId);
            TempData["Success"] = "Speaker assigned successfully.";
            return RedirectToAction(nameof(Sessions));
        }

        // Speakers
        public async Task<IActionResult> Speakers()
        {
            var guard = AdminGuard(); if (guard != null) return guard;

            var speakers = await _speakerRepo.GetSpeakersWithSessionsAsync();
            var vms = speakers.Select(s => new SpeakerViewModel
            {
                SpeakerId   = s.SpeakerId,
                SpeakerName = s.SpeakerName
            }).ToList();
            return View(vms);
        }

        [HttpGet]
        public IActionResult CreateSpeaker()
        {
            var guard = AdminGuard(); if (guard != null) return guard;
            return View(new SpeakerViewModel());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateSpeaker(SpeakerViewModel model)
        {
            var guard = AdminGuard(); if (guard != null) return guard;
            if (!ModelState.IsValid) return View(model);

            await _speakerRepo.AddAsync(new DAL.Models.SpeakersDetails
            {
                SpeakerName = model.SpeakerName
            });

            TempData["Success"] = "Speaker added successfully.";
            return RedirectToAction(nameof(Speakers));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteSpeaker(Guid id)
        {
            var guard = AdminGuard(); if (guard != null) return guard;
            await _speakerRepo.DeleteAsync(id);
            TempData["Success"] = "Speaker removed.";
            return RedirectToAction(nameof(Speakers));
        }
    }
}
