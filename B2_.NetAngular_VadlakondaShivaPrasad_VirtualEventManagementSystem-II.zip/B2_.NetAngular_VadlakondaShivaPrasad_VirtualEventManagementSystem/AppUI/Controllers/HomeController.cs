using AppUI.Models;
using DAL.Repository;
using Microsoft.AspNetCore.Mvc;

namespace AppUI.Controllers
{
    public class HomeController : Controller
    {
        private readonly IEventRepository _eventRepo;
        private readonly ISessionRepository _sessionRepo;

        public HomeController(IEventRepository eventRepo, ISessionRepository sessionRepo)
        {
            _eventRepo = eventRepo;
            _sessionRepo = sessionRepo;
        }

        // GET: / — Home page with active events and category filter
        public async Task<IActionResult> Index(string? category)
        {
            var allEvents = await _eventRepo.GetByStatusAsync("Active");

            if (!string.IsNullOrEmpty(category))
                allEvents = allEvents.Where(e => e.EventCategory == category);

            var categories = await _eventRepo.GetCategoriesAsync();

            var vms = allEvents.Select(e => new EventViewModel
            {
                EventId       = e.EventId,
                EventName     = e.EventName,
                EventCategory = e.EventCategory,
                EventDate     = e.EventDate,
                Description   = e.Description,
                Status        = e.Status
            }).ToList();

            ViewBag.Categories      = categories;
            ViewBag.SelectedCategory = category;
            return View(vms);
        }

        // GET: /Home/EventDetails/id
        public async Task<IActionResult> EventDetails(Guid id)
        {
            var ev = await _eventRepo.GetByIdAsync(id);
            if (ev == null) return NotFound();

            var vm = new EventViewModel
            {
                EventId       = ev.EventId,
                EventName     = ev.EventName,
                EventCategory = ev.EventCategory,
                EventDate     = ev.EventDate,
                Description   = ev.Description,
                Status        = ev.Status,
                Sessions      = ev.Sessions.Select(s => new SessionViewModel
                {
                    SessionId    = s.SessionId,
                    SessionTitle = s.SessionTitle,
                    Description  = s.Description,
                    SessionStart = s.SessionStart,
                    SessionEnd   = s.SessionEnd,
                    SessionUrl   = s.SessionUrl,
                    SpeakerName  = s.Speaker?.SpeakerName
                }).ToList()
            };

            // Check if current participant is already registered
            var email = HttpContext.Session.GetString("UserEmail");
            if (!string.IsNullOrEmpty(email))
                ViewBag.IsRegistered = true;   // simplified; real check uses IParticipantRepo

            return View(vm);
        }

        public IActionResult Error() => View();
    }
}
