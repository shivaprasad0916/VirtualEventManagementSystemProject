using AppUI.Models;
using DAL.Models;
using DAL.Repository;
using Microsoft.AspNetCore.Mvc;

namespace AppUI.Controllers
{
    public class AccountController : Controller
    {
        private readonly IUserRepository _userRepo;

        public AccountController(IUserRepository userRepo) => _userRepo = userRepo;

        // Register
        [HttpGet]
        public IActionResult Register() => View();

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            if (!ModelState.IsValid) return View(model);

            if (await _userRepo.EmailExistsAsync(model.EmailId))
            {
                ModelState.AddModelError("EmailId", "An account with this email already exists.");
                return View(model);
            }

            var user = new UserInfo
            {
                EmailId  = model.EmailId,
                UserName = model.UserName,
                Password = model.Password,
                Role     = "Participant"
            };

            await _userRepo.AddAsync(user);
            TempData["Success"] = "Registration successful! Please log in.";
            return RedirectToAction("Login");
        }

        // Login
        [HttpGet]
        public IActionResult Login(string? returnUrl)
        {
            ViewBag.ReturnUrl = returnUrl;
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginViewModel model, string? returnUrl)
        {
            if (!ModelState.IsValid) return View(model);

            var user = await _userRepo.AuthenticateAsync(model.EmailId, model.Password);
            if (user == null)
            {
                ModelState.AddModelError("", "Invalid email or password.");
                return View(model);
            }

            // Store session values
            HttpContext.Session.SetString("UserEmail", user.EmailId);
            HttpContext.Session.SetString("UserName",  user.UserName);
            HttpContext.Session.SetString("UserRole",  user.Role);

            if (user.Role == "Admin")
                return RedirectToAction("Dashboard", "Admin");

            if (!string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl))
                return Redirect(returnUrl);

            return RedirectToAction("Dashboard", "Participant");
        }

        //Logout
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index", "Home");
        }
    }
}
