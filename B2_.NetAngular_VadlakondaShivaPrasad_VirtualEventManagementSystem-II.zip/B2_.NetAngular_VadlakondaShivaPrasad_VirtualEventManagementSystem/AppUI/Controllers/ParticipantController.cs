using AppUI.Models;
using DAL.Models;
using DAL.Repository;
using Microsoft.AspNetCore.Mvc;

namespace AppUI.Controllers
{
    public class ParticipantController : Controller
    {
        private readonly IEventRepository       _eventRepo;
        private readonly IParticipantRepository _participantRepo;
        private readonly ISessionRepository     _sessionRepo;

        public ParticipantController(
            IEventRepository       eventRepo,
            IParticipantRepository participantRepo,
            ISessionRepository     sessionRepo)
        {
            _eventRepo       = eventRepo;
            _participantRepo = participantRepo;
            _sessionRepo     = sessionRepo;
        }

        private string? CurrentEmail => HttpContext.Session.GetString("UserEmail");

        private IActionResult ParticipantGuard()
        {
            if (string.IsNullOrEmpty(CurrentEmail))
                return RedirectToAction("Login", "Account",
                    new { returnUrl = Request.Path.ToString() });
            return null!;
        }

        // Dashboard
        public async Task<IActionResult> Dashboard()
        {
            var guard = ParticipantGuard(); if (guard != null) return guard;

            var registrations = await _participantRepo.GetByParticipantAsync(CurrentEmail!);
            ViewBag.RegisteredCount = registrations.Count();
            ViewBag.AttendedCount   = registrations.Count(r => r.IsAttended);
            return View();
        }

        // Registered Events
        public async Task<IActionResult> RegisteredEvents()
        {
            var guard = ParticipantGuard();
            if (guard != null)
            {
                return guard;
            }

            var registrations = await _participantRepo.GetByParticipantAsync(CurrentEmail!);
            var vms = registrations.Select(r => new ParticipantEventViewModel
            {
                ID                 = r.ID,
                ParticipantEmailId = r.ParticipantEmailId,
                EventId            = r.EventId,
                IsAttended         = r.IsAttended,
                Event = r.Event == null ? null : new EventViewModel
                {
                    EventId       = r.Event.EventId,
                    EventName     = r.Event.EventName,
                    EventCategory = r.Event.EventCategory,
                    EventDate     = r.Event.EventDate,
                    Status        = r.Event.Status,
                    Sessions      = r.Event.Sessions.Select(s => new SessionViewModel
                    {
                        SessionId    = s.SessionId,
                        SessionTitle = s.SessionTitle,
                        SpeakerName  = s.Speaker?.SpeakerName,
                        SessionStart = s.SessionStart,
                        SessionEnd   = s.SessionEnd,
                        SessionUrl   = s.SessionUrl
                    }).ToList()
                }
            }).ToList();

            return View(vms);
        }

        // Register for Event
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> RegisterEvent(Guid eventId)
        {
            var guard = ParticipantGuard();
            if (guard != null)
            {
                return guard;
            }
            if (await _participantRepo.IsRegisteredAsync(CurrentEmail!, eventId))
            {
                TempData["Error"] = "You are already registered for this event.";
                return RedirectToAction("EventDetails", "Home", new { id = eventId });
            }

            var ev = await _eventRepo.GetByIdAsync(eventId);
            if (ev == null || ev.Status != "Active")
            {
                TempData["Error"] = "This event is not available for registration.";
                return RedirectToAction("Index", "Home");
            }

            await _participantRepo.AddAsync(new ParticipantEventDetails
            {
                ParticipantEmailId = CurrentEmail!,
                EventId            = eventId,
                IsAttended         = false
            });

            TempData["Success"] = $"You have successfully registered for \"{ev.EventName}\".";
            return RedirectToAction(nameof(RegisteredEvents));
        }

        // Mark Attendance
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> MarkAttendance(Guid registrationId, bool attended)
        {
            var guard = ParticipantGuard();
            if (guard != null)
            {
                return guard;
            }
            await _participantRepo.MarkAttendanceAsync(registrationId, attended);
            TempData["Success"] = "Attendance updated.";
            return RedirectToAction(nameof(RegisteredEvents));
        }

        // Cancel Registration
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CancelRegistration(Guid registrationId)
        {
            var guard = ParticipantGuard(); if (guard != null) return guard;
            await _participantRepo.DeleteAsync(registrationId);
            TempData["Success"] = "Registration cancelled.";
            return RedirectToAction(nameof(RegisteredEvents));
        }
    }
}
