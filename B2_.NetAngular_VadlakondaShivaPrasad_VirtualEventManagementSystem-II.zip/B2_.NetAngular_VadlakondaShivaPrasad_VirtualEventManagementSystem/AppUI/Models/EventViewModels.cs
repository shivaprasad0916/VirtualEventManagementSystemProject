using System.ComponentModel.DataAnnotations;

namespace AppUI.Models
{
    // Event
    public class EventViewModel
    {
        public Guid EventId { get; set; }

        [Required(ErrorMessage = "Event name is required.")]
        [StringLength(50, MinimumLength = 1, ErrorMessage = "Event name must be 1–50 characters.")]
        [Display(Name = "Event Name")]
        public string EventName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Category is required.")]
        [StringLength(50, MinimumLength = 1, ErrorMessage = "Category must be 1–50 characters.")]
        [Display(Name = "Category")]
        public string EventCategory { get; set; } = string.Empty;

        [Required(ErrorMessage = "Event date is required.")]
        [DataType(DataType.Date)]
        [Display(Name = "Event Date")]
        public DateTime EventDate { get; set; } = DateTime.Today.AddDays(1);

        [Display(Name = "Description")]
        public string? Description { get; set; }

        [Required]
        [Display(Name = "Status")]
        public string Status { get; set; } = "Active";

        public List<SessionViewModel> Sessions { get; set; } = new();
    }

    // Session
    public class SessionViewModel
    {
        public Guid SessionId { get; set; }

        [Required(ErrorMessage = "Please select an event.")]
        [Display(Name = "Event")]
        public Guid EventId { get; set; }

        [Required(ErrorMessage = "Session title is required.")]
        [StringLength(50, MinimumLength = 1, ErrorMessage = "Title must be 1–50 characters.")]
        [Display(Name = "Session Title")]
        public string SessionTitle { get; set; } = string.Empty;

        [Display(Name = "Speaker")]
        public Guid? SpeakerId { get; set; }

        [Display(Name = "Description")]
        public string? Description { get; set; }

        [Required(ErrorMessage = "Start time is required.")]
        [DataType(DataType.DateTime)]
        [Display(Name = "Session Start")]
        public DateTime SessionStart { get; set; }

        [Required(ErrorMessage = "End time is required.")]
        [DataType(DataType.DateTime)]
        [Display(Name = "Session End")]
        public DateTime SessionEnd { get; set; }

        [DataType(DataType.Url)]
        [Display(Name = "Session URL")]
        public string? SessionUrl { get; set; }

        // Display helpers
        public string? EventName { get; set; }
        public string? SpeakerName { get; set; }
    }

    // Speaker
    public class SpeakerViewModel
    {
        public Guid SpeakerId { get; set; }

        [Required(ErrorMessage = "Speaker name is required.")]
        [StringLength(50, MinimumLength = 1, ErrorMessage = "Name must be 1–50 characters.")]
        [Display(Name = "Speaker Name")]
        public string SpeakerName { get; set; } = string.Empty;
    }

    // Assign Speaker
    public class AssignSpeakerViewModel
    {
        [Required]
        public Guid SessionId { get; set; }

        [Required(ErrorMessage = "Please select a speaker.")]
        [Display(Name = "Speaker")]
        public Guid SpeakerId { get; set; }

        public string? SessionTitle { get; set; }
        public List<SpeakerViewModel> AvailableSpeakers { get; set; } = new();
    }

    // Participant Registration
    public class ParticipantEventViewModel
    {
        public Guid ID { get; set; }
        public string ParticipantEmailId { get; set; } = string.Empty;
        public Guid EventId { get; set; }
        public bool IsAttended { get; set; }

        // Display helpers
        public EventViewModel? Event { get; set; }
    }
}
